import MySQLdb
db = MySQLdb.connect("localhost","root","123","student" )
cursor = db.cursor()
# Prepare SQL query to UPDATE required records
sql = "UPDATE EMPLOYEE SET AGE = AGE + 1 WHERE SEX = 'M'"
#sql = "UPDATE EMPLOYEE SET AGE = 50 WHERE FIRST_NAME = 'karan'"
try:
   # Execute the SQL command
   cursor.execute(sql)
   # Commit your changes in the database
   db.commit()
except:
   # Rollback in case there is any error
   db.rollback()


db.close()



