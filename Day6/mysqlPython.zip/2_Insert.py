import MySQLdb
db = MySQLdb.connect("localhost","root","123","student" )
cursor = db.cursor()
a=raw_input("Enter First Name: ")
b=raw_input("Enter Last Name: ")
c=input("Enter Age: ")
d=raw_input("Enter Sex: ")
e=input("Enter Salary: ")
# Prepare SQL query to INSERT a record into the database.
sql = "INSERT INTO EMPLOYEE(FIRST_NAME,LAST_NAME, AGE, SEX, INCOME) VALUES ('%s', '%s', '%d', '%c', '%d' )" % (a,b,c,d,e)
try:
   # Execute the SQL command
   cursor.execute(sql)
   print "Values Inserted Successfully"
   # Commit your changes in the database
   db.commit()
except:
   # Rollback in case there is any error
   print "Values Not Inserted"
   db.rollback()

db.close()


